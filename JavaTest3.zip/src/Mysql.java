
public class Mysql extends Database{
	public void open() {
		System.out.println("Mysql Open");
	}
}
