package com.test2;

import com.test.*;
public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClass obj = new MyClass();
		obj.a=1;
		obj.aMethod();
		
	}

}
