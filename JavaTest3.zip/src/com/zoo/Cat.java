package com.zoo;
class Duck{
	
}
public class Cat {
	public void makeCat() {
		Duck quack = new Duck();
		
	}
}
