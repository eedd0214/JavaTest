package com.test;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClass a= new MyClass();
		a.a=10;
		a.c=20;
		a.aMethod();
		a.cMethod();
	}

}
