package com.test;

public class MyClass {//
	//public , private, protected, default
	public int a;
	private int b;
	protected int c;
	int d;
	public void aMethod() {}
	private void bMethod() {}
	protected void cMethod() {}
	void dMethod() {}
	
	
}
