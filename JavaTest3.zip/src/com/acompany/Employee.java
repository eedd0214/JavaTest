package com.acompany;

public class Employee {
	private String name;
	public void setName(String nm) {
		name=nm;
	}
	public void gotoCompany() {
		System.out.println(name+"�� ȸ�翡 ����.");
	}
}
