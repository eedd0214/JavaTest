
public class Database {
	public void open() {
		System.out.println("Database Open");
	}
	
}
