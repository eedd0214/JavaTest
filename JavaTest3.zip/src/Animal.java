/*
*Overloading
*Overriding
*/
public class Animal {
	public void breath() {
		System.out.println("Animal Breath");
	}
	
	
}
