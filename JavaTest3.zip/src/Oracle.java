
public class Oracle extends Database{
	public void open() {
		System.out.println("Oracle Open");
	}
}
