
public class Cat extends Animal {
	
	public void Meow() {
		System.out.println("Cat Meow--------");
	}
	public void breath() {
		System.out.println("Cat breath");
	}
}
