import com.acompany.*;
import com.bcompany.*;

public class Test5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Employee emp3 = new Employee();
		//com.acompany.Employee emp= new com.acompany.Employee();

		//com.bcompany.Employee emp2 = new com.bcompany.Employee();
		
	}

}
