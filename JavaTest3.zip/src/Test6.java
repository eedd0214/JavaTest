class BankAccount{
	String accNumber;
	String ssNumber;
	int balance=0;
	
	public void initAcoount(String acc, String ss, int bal) {
		accNumber=acc;
		ssNumber=ss;
		balance=bal;
	}
	public int deposit(int amount) {
		balance += amount;
		return balance;
	}
	public int withdraw(int amount) {
		balance -= amount;
		return balance;
	}
	public int checkMyBalance() {
		System.out.println("���¹�ȣ : "+accNumber);
		System.out.println("�ֹι�ȣ : "+ssNumber);
		System.out.println("�ܾ� : "+balance+"\n");
		return balance;
	}
}
public class Test6 {
	public static void main(String[] args) {
		BankAccount yoon= new BankAccount();
		yoon.initAcoount("12-14-89","990990-9990990",10000);
		
		BankAccount park= new BankAccount();
		park.initAcoount("33-55-09","770088-5959007",10000);
	
		yoon.deposit(5000);
		park.deposit(3000);
		yoon.withdraw(2000);
		park.withdraw(2000);
		yoon.checkMyBalance();
		park.checkMyBalance();
	}

}
